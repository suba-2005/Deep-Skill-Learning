package com.library.repository;

public class BookRepository {
    public void getAllBooks() {
        System.out.println("Fetching books from the repository...");
    }
}
